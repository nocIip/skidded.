Basically yh jus put ur token in config.json
If your token is incorrect the exe will shutdown so if you think it doesn't work just check your token lol.

P1 Was Here.