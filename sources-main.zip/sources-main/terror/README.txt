creds 2 owners
 remove the #line(the number)